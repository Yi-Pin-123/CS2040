import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

class Edge implements Comparable<Edge> {
    int source;
    int dest;
    int weight;

    public Edge(int source, int dest, int weight) {
        this.source = source;
        this.dest = dest;
        this.weight = weight;
    }

    @Override
    public int compareTo(Edge other) {
        return this.weight - other.weight;
    }
}

public class FindMap {

    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        
        // Read number of vertices
        int V = Integer.parseInt(reader.readLine());
        
        // Read adjacency matrix
        int[][] adjMatrix = new int[V][V];
        for (int i = 0; i < V; i++) {
            String[] input = reader.readLine().split(" ");
            for (int j = 0; j < V; j++) {
                adjMatrix[i][j] = Integer.parseInt(input[j]);
            }
        }

        // Convert adjacency matrix to list of edges
        List<Edge> edges = new ArrayList<>();
        for (int i = 0; i < V; i++) {
            for (int j = i + 1; j < V; j++) {
                if (adjMatrix[i][j] != 0) { // Assuming 0 means no direct edge
                    edges.add(new Edge(i, j, adjMatrix[i][j]));
                }
            }
        }

        // Sort edges by weight
        Collections.sort(edges);

        // Create the union find structure
        UnionFind ufds = new UnionFind(V);

        // Kruskal's algorithm to find MST
        for (Edge edge : edges) {
            if (!ufds.isSameSet(edge.source, edge.dest)) {
                ufds.unionSet(edge.source, edge.dest);
                // Print the vertices at the start and end of each edge in the MST
                System.out.println((edge.source + 1) + " " + (edge.dest + 1));
            }
        }
    }
}
