import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.IOException;

public class AlmostUnionFind {
    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        PrintWriter pw = new PrintWriter(System.out);

        String line;
        while ((line = br.readLine()) != null && !line.isEmpty()) { // Loop until EOF
            String[] parts = line.split(" ");
            int N = Integer.parseInt(parts[0]); // Number of elements for this test case
            int M = Integer.parseInt(parts[1]); // Number of operations for this test case

            UFDS ufds = new UFDS(N); // Create a new UFDS instance for each test case

            for (int i = 0; i < M; i++) {
                line = br.readLine();
                parts = line.split(" ");
                int command = Integer.parseInt(parts[0]);
                switch (command) {
                    case 1: { // Union set
                        int p = Integer.parseInt(parts[1]);
                        int q = Integer.parseInt(parts[2]);

                        // Handle fake parents
                        int parentP = ufds.parent[p].fake != null ? ufds.parent[p].fake : p;
                        int parentQ = ufds.parent[q].fake != null ? ufds.parent[q].fake : q;

                        ufds.unionSet(parentP, parentQ);
                        break;
                    }
                    case 2: { // Move p to the set containing q
                        int p = Integer.parseInt(parts[1]);
                        int q = Integer.parseInt(parts[2]);

                        int parentQ = ufds.parent[q].fake != null ? ufds.parent[q].fake : q;
                        ufds.move(p, parentQ);
                        break;
                    }
                    case 3: { // Get the count and sum of the set that p belongs to
                        int p = Integer.parseInt(parts[1]);

                        int parent;
                        if (ufds.parent[p].fake != null) {
                            parent = ufds.findSet(ufds.parent[p].fake);
                        } else {
                            parent = ufds.findSet(p);
                        }

                        int elementCount = ufds.count[parent];
                        long elementSum = ufds.sum[parent];

                        pw.println(elementCount + " " + elementSum);
                        break;
                    }
                }
            }
        }

        pw.close();
        br.close();
    }
}