import java.util.Arrays;

class Vertex {
    int real;
    Integer fake;

    Vertex(int real) {
        this.real = real;
        this.fake = null;
    }
}

class UFDS {
    public Vertex[] parent;
    public int[] rank;
    public int[] count;
    public long[] sum;

    public UFDS(int N) {
        parent = new Vertex[N + 1];
        rank = new int[N + 1];
        count = new int[N + 1];
        sum = new long[N + 1];

        for (int i = 0; i <= N; i++) {
            parent[i] = new Vertex(i);
            count[i] = 1;
            sum[i] = i;
            rank[i] = 0;
        }
    }

    public int findSet(int i) {
        if (parent[i].real != i)
            parent[i].real = findSet(parent[i].real);
        return parent[i].real;
    }

    public boolean isSameSet(int i, int j) {
        return findSet(i) == findSet(j);
    }

    public void unionSet(int i, int j) {
        if (!isSameSet(i, j)) {
            int x = findSet(i);
            int y = findSet(j);

            if (rank[x] > rank[y]) {
                parent[y].real = x;
                count[x] += count[y];
                sum[x] += sum[y];
                //sum[y] = 0L;
            } else {
                parent[x].real = y;
                count[y] += count[x];
                sum[y] += sum[x];
                //sum[x] = 0L;

                if (rank[x] == rank[y])
                    rank[y]++;
            }
        }
    }
    public void move(int p, int q) {
        
        int rootP = findSet(p);
        int rootQ = findSet(q);

            if (parent[p].fake == null) { //p has not been moved before
                parent[p].fake = rootQ;
            } else { // p has been moved before
                int fakeParent = parent[p].fake;
                rootP = findSet(fakeParent);
                if (rootP == rootQ){return ;}
                parent[p].fake = rootQ;
            }

            count[rootP]--;
            sum[rootP] -= p;
            sum[rootQ] += p;
            count[rootQ]++;
        
    }

}
