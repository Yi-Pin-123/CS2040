import java.util.*;

class AVLVertex {
  // Existing attributes
  public AVLVertex parent, left, right;
  public int height, size;
  public String key;
  

  AVLVertex(String v) {
    key = v; parent = left = right = null; height = 0; size = 1; // Initialize size as 1 for a single vertex
  }

  // New method to update height
  public void updateHeight() {
    int leftHeight = (left == null) ? -1 : left.height;
    int rightHeight = (right == null) ? -1 : right.height;
    height = Math.max(leftHeight, rightHeight) + 1;
  }

  // New method to get balance factor
  public int getBalanceFactor() {
    int leftHeight = (left == null) ? -1 : left.height;
    int rightHeight = (right == null) ? -1 : right.height;
    return leftHeight - rightHeight;
  }
  
  public void updateSize() {
    int leftSize = (left == null) ? 0 : left.size;
    int rightSize = (right == null) ? 0 : right.size;
    size = leftSize + rightSize + 1; // Sum of sizes of left and right children plus itself
  }
}

class AVLforString {
  private AVLVertex root; // Define root as a member variable of the AVL class
  
  public AVLforString() {
    root = null; // Initialize root in the constructor
  }
  
  public int countMatches(String nickname) {
    return countMatches(root, nickname);
  }
  
  private int countMatches(AVLVertex T, String nickname) {
    if (T == null) return 0;

    // Check if the current node's key starts with the nickname
    if (startsWith(T.key, nickname)) {
        // Count this node and continue searching both subtrees
        return 1 + countMatches(T.left, nickname) + countMatches(T.right, nickname);
    } else if (nickname.compareTo(T.key) < 0) {
        // Nickname is lexicographically smaller, check left subtree
        return countMatches(T.left, nickname);
    } else {
        // Nickname is lexicographically greater, check right subtree
        return countMatches(T.right, nickname);
    }
  }

  private boolean startsWith(String name, String prefix) {
    return name.startsWith(prefix);
  }
  
  // method to rebalance the tree at given vertex if the tree unbalanced
  private AVLVertex rebalance(AVLVertex T) {
    int balanceFactor = T.getBalanceFactor();

    if (balanceFactor > 1) {
      if (T.left.getBalanceFactor() >= 0) { // Left Left Case
        T = rotateRight(T);
      } else { // Left Right Case
        T.left = rotateLeft(T.left);
        T = rotateRight(T);
      }
    } else if (balanceFactor < -1) {
      if (T.right.getBalanceFactor() <= 0) { // Right Right Case
        T = rotateLeft(T);
      } else { // Right Left Case
        T.right = rotateRight(T.right);
        T = rotateLeft(T);
      }
    }

    return T;
  }

  // Rotation methods
  private AVLVertex rotateLeft(AVLVertex T) {
    AVLVertex w = T.right;
    w.parent = T.parent;
    T.parent = w;
    T.right = w.left;
    if (w.left != null) w.left.parent = T;
    w.left = T;

    T.updateHeight();
    w.updateHeight();
    
    T.updateSize(); // Update size
    w.updateSize(); // Update size

    return w;
  }

  private AVLVertex rotateRight(AVLVertex T) {
    AVLVertex w = T.left;
    w.parent = T.parent;
    T.parent = w;
    T.left = w.right;
    if (w.right != null) w.right.parent = T;
    w.right = T;

    T.updateHeight();
    w.updateHeight();
    
    T.updateSize(); // Update size
    w.updateSize(); // Update size

    return w;
  }

  // Modified insert and delete methods
  public void insert(String v) {
    root = insert(root, v);
  }

  private AVLVertex insert(AVLVertex T, String v) {
    // Adapted for String comparisons
    if (T == null) return new AVLVertex(v); // insertion point is found

    if (T.key.compareTo(v) < 0) { // search to the right
      T.right = insert(T.right, v);
      T.right.parent = T;
    } else { // search to the left
      T.left = insert(T.left, v);
      T.left.parent = T;
    }

    // Update height and rebalance
    T.updateHeight();
    T.updateSize(); // Update size here
    return rebalance(T);
  }
/*** delete function dont need
  @Override
  public void delete(String v) {
    root = delete(root, v);
  }

  private BSTVertex delete(BSTVertex T, int v) {
    // Standard BST delete (same as before)
    
    if (T == null)  return T;              // cannot find the item to be deleted

    if (T.key < v)                                    // search to the right
      T.right = delete(T.right, v);
    else if (T.key > v)                               // search to the left
      T.left = delete(T.left, v);
    else {                                            // this is the node to be deleted
      if (T.left == null && T.right == null)                   // this is a leaf
        T = null;                                      // simply erase this node
      else if (T.left == null && T.right != null) {   // only one child at right        
        T.right.parent = T.parent;
        T = T.right;                                                 // bypass T        
      }
      else if (T.left != null && T.right == null) {    // only one child at left        
        T.left.parent = T.parent;
        T = T.left;                                                  // bypass T        
      }
      else {                                 // has two children, find successor
        int successorV = successor(v);
        T.key = successorV;         // replace this key with the successor's key
        T.right = delete(T.right, successorV);      // delete the old successorV
      }
    }

    if (T != null) {
      // Update height and rebalance
      T.updateHeight();
      T.updateSize(); // Update size here
      T = rebalance(T);
    }

    return T;
  } 
  ***/
}
