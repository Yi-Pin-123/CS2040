import java.util.HashMap;
import java.util.Map;

public class NickNames {
    public static void main(String[] args) {
        Kattio io = new Kattio(System.in, System.out);
        AVLforString avlTree = new AVLforString();
        Map<String, Integer> nicknameDictionary = new HashMap<>(); // Dictionary to store nicknames and counts

        // Read the number of names and insert them into the AVL Tree
        int numberOfNames = io.getInt();
        for (int i = 0; i < numberOfNames; i++) {
            avlTree.insert(io.getWord());
        }

        // Read the number of nicknames and process them
        int numberOfNicknames = io.getInt();
        for (int i = 0; i < numberOfNicknames; i++) {
            String nickname = io.getWord();
            // Check if nickname is in the dictionary
            if (nicknameDictionary.containsKey(nickname)) {
                // If yes, then just print the corresponding value
                io.println(nicknameDictionary.get(nickname));
            } else {
                // If not, traverse the tree to count matches
                int count = avlTree.countMatches(nickname);
                nicknameDictionary.put(nickname, count); // Store the result in the dictionary
                io.println(count);
            }
        }

        io.close();
    }
}
