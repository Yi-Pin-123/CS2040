import java.util.*;

public class ModifiedKosaraju {
    private int V;   // Number of vertices
    private List<List<Integer>> adj;   // Adjacency list for original graph
    //private List<List<Integer>> revAdj;   // Adjacency list for transposed graph

    public void KosarajuAlgorithm(int v) {
        // settiing up the stuff like how Kosaraju but dont need reverse
        V = v;
        adj = new ArrayList<>(v);
        //revAdj = new ArrayList<>(v);
        for (int i = 0; i < v; i++) {
            adj.add(new ArrayList<>());
            //revAdj.add(new ArrayList<>());
        }
    }

    // Function to add an edge to the graph
    public void addEdge(int v, int w) {
        adj.get(v).add(w);
        //revAdj.get(w).add(v);
    }

    // A recursive function to perform DFS on the graph
    private void DFSUtil(int v, boolean visited[], List<List<Integer>> adj, Stack<Integer> stack) {
        // Mark the current node as visited
        visited[v] = true;

        // Recur for all the vertices adjacent to this vertex
        for (int n : adj.get(v)) {
            if (!visited[n])
                DFSUtil(n, visited, adj, stack);
        }

        // All vertices reachable from v are processed, push v to Stack
        if (stack != null) {
            stack.push(v);
        }
    }

    // funciton that counts how pushes to complete the domino
    // this part is different from the original Kosaraju
    public int countPushes() {
        int counter = 0;
        Stack<Integer> stack = new Stack<>();

        // Mark all the vertices as not visited (For first DFS)
        boolean visited[] = new boolean[V];
        Arrays.fill(visited, false);

        // Fill vertices in stack according to their finishing times
        for (int i = 0; i < V; i++)
            if (!visited[i])
                DFSUtil(i, visited, adj, stack);

        // Mark all the vertices as not visited (For second DFS)
        Arrays.fill(visited, false);

        // Now process all vertices in order defined by Stack
        while (!stack.empty()) {
            // Pop a vertex from stack
            int v = stack.pop();

            if (!visited[v]) {
                counter += 1;
                DFSUtil(v, visited, adj, null);
            }
        }
        return counter;
    }
}

