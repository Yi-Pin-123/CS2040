import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
import java.util.StringTokenizer;

public class DominoKiller {

    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        int numberOfTestCases = Integer.parseInt(reader.readLine());
        
        for (int t = 0; t < numberOfTestCases; t++) {
            StringTokenizer st = new StringTokenizer(reader.readLine());
            int graphSize = Integer.parseInt(st.nextToken());
            int numberOfEdges = Integer.parseInt(st.nextToken());
            
            ModifiedKosaraju domino = new ModifiedKosaraju();
            domino.KosarajuAlgorithm(graphSize);
            
            for (int i = 0; i < numberOfEdges; i++) {
                st = new StringTokenizer(reader.readLine());
                int from = Integer.parseInt(st.nextToken());
                int to = Integer.parseInt(st.nextToken());
                
                // Adjusting for zero-based index if necessary, assuming addEdge method exists
                domino.addEdge(from - 1, to - 1);
            }
            
            // Assuming countPushes calculates and returns the required result
            int result = domino.countPushes();
            System.out.println(result);
        }
    }
}
